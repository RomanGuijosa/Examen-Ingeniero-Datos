import json
import boto3
import requests
import os

s3 = boto3.client('s3')
bucket_name = os.environ['BUCKET_NAME']
endpoint_url = os.environ['ENDPOINT_URL']

def lambda_handler(event, context):
    start_id = 1
    end_id = 500

    for pokemon_id in range(start_id, end_id + 1):
        url = f"{endpoint_url}/{pokemon_id}"
        response = requests.get(url)
        
        if response.status_code == 200:
            pokemon_data = response.json()
            file_name = f"pokemon_{pokemon_id}.json"
            
            s3.put_object(
                Bucket=bucket_name,
                Key=file_name,
                Body=json.dumps(pokemon_data)
            )
        else:
            print(f"Error al obtener datos para el Pokémon con ID {pokemon_id}")

    return {
        'statusCode': 200,
        'body': json.dumps('Proceso completado.')
    }


